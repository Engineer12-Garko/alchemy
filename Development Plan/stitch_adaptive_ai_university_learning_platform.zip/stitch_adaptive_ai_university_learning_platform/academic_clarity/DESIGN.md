---
name: Academic Clarity
colors:
  surface: '#f8f9ff'
  surface-dim: '#cbdbf5'
  surface-bright: '#f8f9ff'
  surface-container-lowest: '#ffffff'
  surface-container-low: '#eff4ff'
  surface-container: '#e5eeff'
  surface-container-high: '#dce9ff'
  surface-container-highest: '#d3e4fe'
  on-surface: '#0b1c30'
  on-surface-variant: '#44474c'
  inverse-surface: '#213145'
  inverse-on-surface: '#eaf1ff'
  outline: '#75777d'
  outline-variant: '#c5c6cd'
  surface-tint: '#525f75'
  primary: '#000000'
  on-primary: '#ffffff'
  primary-container: '#0e1c2f'
  on-primary-container: '#77849c'
  inverse-primary: '#bac7e1'
  secondary: '#006a61'
  on-secondary: '#ffffff'
  secondary-container: '#86f2e4'
  on-secondary-container: '#006f66'
  tertiary: '#000000'
  on-tertiary: '#ffffff'
  tertiary-container: '#0f0069'
  on-tertiary-container: '#7671ff'
  error: '#ba1a1a'
  on-error: '#ffffff'
  error-container: '#ffdad6'
  on-error-container: '#93000a'
  primary-fixed: '#d6e3fe'
  primary-fixed-dim: '#bac7e1'
  on-primary-fixed: '#0e1c2f'
  on-primary-fixed-variant: '#3a475c'
  secondary-fixed: '#89f5e7'
  secondary-fixed-dim: '#6bd8cb'
  on-secondary-fixed: '#00201d'
  on-secondary-fixed-variant: '#005049'
  tertiary-fixed: '#e2dfff'
  tertiary-fixed-dim: '#c3c0ff'
  on-tertiary-fixed: '#0f0069'
  on-tertiary-fixed-variant: '#3323cc'
  background: '#f8f9ff'
  on-background: '#0b1c30'
  surface-variant: '#d3e4fe'
typography:
  display-hero:
    fontFamily: Plus Jakarta Sans
    fontSize: 48px
    fontWeight: '700'
    lineHeight: 56px
    letterSpacing: -0.025em
  display-hero-mobile:
    fontFamily: Plus Jakarta Sans
    fontSize: 32px
    fontWeight: '700'
    lineHeight: 40px
    letterSpacing: -0.02em
  headline-lg:
    fontFamily: Plus Jakarta Sans
    fontSize: 36px
    fontWeight: '600'
    lineHeight: 44px
    letterSpacing: -0.02em
  headline-lg-mobile:
    fontFamily: Plus Jakarta Sans
    fontSize: 26px
    fontWeight: '600'
    lineHeight: 34px
    letterSpacing: -0.015em
  headline-md:
    fontFamily: Plus Jakarta Sans
    fontSize: 24px
    fontWeight: '600'
    lineHeight: 32px
    letterSpacing: -0.015em
  headline-sm:
    fontFamily: Plus Jakarta Sans
    fontSize: 20px
    fontWeight: '600'
    lineHeight: 28px
    letterSpacing: -0.01em
  title-md:
    fontFamily: Plus Jakarta Sans
    fontSize: 16px
    fontWeight: '600'
    lineHeight: 24px
    letterSpacing: -0.005em
  body-lg:
    fontFamily: Inter
    fontSize: 18px
    fontWeight: '400'
    lineHeight: 28px
  body-md:
    fontFamily: Inter
    fontSize: 15px
    fontWeight: '400'
    lineHeight: 24px
  body-sm:
    fontFamily: Inter
    fontSize: 13px
    fontWeight: '400'
    lineHeight: 20px
  label-md:
    fontFamily: Inter
    fontSize: 13px
    fontWeight: '500'
    lineHeight: 18px
    letterSpacing: 0.01em
  label-sm:
    fontFamily: Inter
    fontSize: 11px
    fontWeight: '600'
    lineHeight: 16px
    letterSpacing: 0.04em
  code-inline:
    fontFamily: Inter
    fontSize: 13px
    fontWeight: '400'
    lineHeight: 20px
rounded:
  sm: 0.25rem
  DEFAULT: 0.5rem
  md: 0.75rem
  lg: 1rem
  xl: 1.5rem
  full: 9999px
spacing:
  gutter: 1.5rem
  gutter-mobile: 1rem
  margin: 2rem
  margin-mobile: 1rem
  space-xs: 0.25rem
  space-sm: 0.5rem
  space-md: 1rem
  space-lg: 1.5rem
  space-xl: 2.5rem
---

## Brand & Style

This design system establishes an academic environment rooted in intellectual rigor, composure, and effortless focus. Engineered for undergraduate, graduate, and professional scholars spanning STEM, Business, and Humanities disciplines, the interface minimizes cognitive friction while projecting institutional-grade credibility.

The visual ethos blends **Refined Modern Minimalism** with **Cognitive Calm**:
- **Clarity over novelty:** Visual hierarchies are sharp, functional, and self-evident. Unnecessary ornamentation, intense chromatic gradients, and gratuitous transitions are rejected in favor of structured data presentation and pristine legibility.
- **Academic authority meets contemporary utility:** Deep navy substrates project structure and permanence, while light slate foundations and crisp teal/indigo accents encourage sustained focus during intensive research, synthesis, and problem-solving sessions.
- **Measured, purposeful feedback:** Micro-interactions reinforce positive study momentum without gamifying serious scholarship into distraction.

## Colors

The palette balances deep architectural anchors with analytical accents and unambiguous pedagogical indicators.

### Foundational Palette
- **Primary Navy (`#0B192C`):** Represents institutional authority, structural chrome, primary navigation, and highest-emphasis headings.
- **Navy Elevated (`#1E2E42`):** Used for elevated dark surfaces, secondary headers, and high-contrast structural cards.
- **Background Slate (`#F8FAFC`):** The primary canvas across all viewports; provides high-contrast support for text while mitigating ocular strain over long study blocks.
- **Surface Crisp (`#FFFFFF`):** High-priority card bodies, reading surfaces, and interactive input fields.
- **Surface Muted (`#F1F5F9`):** Canvas grouping containers, nested panels, and neutral inactive badge backgrounds.
- **Borders & Dividers (`#E2E8F0`):** Precise 1px boundaries defining structural hierarchy across white and slate substrates.

### Semantic & Cognitive Accents
- **Intelligent Teal (`#0D9488`, hover `#14B8A6`):** Primary action items, interactive discovery highlights, and active pedagogical states.
- **Scholastic Indigo (`#4F46E5`):** Curricular milestones, citation highlights, syllabus tags, and disciplinary contextual tags.
- **Progress Emerald (`#10B981`):** Mastery confirmation, syllabus completion, and verified solutions.
- **Diagnostic Amber (`#F59E0B`):** Logical misconceptions, pending peer reviews, and review-due markers.
- **Diagnostic Rose (`#EF4444`):** Concept bottlenecks, unresolved learning gaps, and critical prerequisites.

## Typography

The typographic hierarchy couples **Plus Jakarta Sans** for structural wayfinding and headings with **Inter** for sustained reading, dense metadata, and numerical assessment.

- **Headings & Display:** Plus Jakarta Sans introduces welcoming modernity without sacrificing scholarly seriousness. Tighter tracking (`-0.01em` to `-0.025em`) ensures cohesion across complex academic titles and module headings.
- **Body & Longform:** Inter provides objective, distortion-free rendering for technical formulas, legal case briefs, and dense prose. Body line heights adhere to a comfortable 1.5x–1.6x baseline to prevent tracking fatigue.
- **Metadata & Indicators:** Small labels (`label-sm`) employ slight letter-spacing (`0.04em`) and uppercase rendering when denoting status flags, course catalog numbers (e.g., `ECON-4010`), and learning taxonomy markers.

## Layout & Spacing

The layout follows an 8-point rhythmic grid designed around a **fluid 12-column responsive layout** on desktop and a **4-column structured framework** on mobile devices.

### Breakpoints & Adaptive Strategy
- **Mobile (< 768px):** 4 columns, `margin-mobile` (1rem / 16px), and `gutter-mobile` (1rem / 16px). Side navigation reflows into a bottom docking bar for thumb-zone access to primary learning hubs (Courses, Study, Progress, Account).
- **Tablet (768px – 1023px):** 8 columns, 1.5rem margins, 1.25rem gutters. Secondary contextual sidebars collapse into persistent slide-over drawers.
- **Desktop (1024px+):** 12 columns, `margin` (2rem / 32px), and `gutter` (1.5rem / 24px) capped at a max-content boundary of 1440px to ensure line-length constraints on long-form academic texts do not exceed 75 characters.

### Sectional Rhythm
- Intra-component spacing defaults strictly to `space-sm` (8px) and `space-md` (16px).
- Inter-card and module grouping uses `space-lg` (24px) to keep modules decoupled and mentally digestible.
- Major pedagogical sections (e.g., transition from "Assigned Modules" to "Diagnostic Insights") require `space-xl` (40px) to establish unambiguous conceptual boundaries.

## Elevation & Depth

Visual depth is achieved through **tonal surface stacking** combined with **subtle low-contrast borders** and ultra-diffused ambient contact shadows. Deep drop shadows and heavy gloss treatments are avoided.

### Elevation Hierarchy
- **Level 0 (Canvas Base):** Surface color `#F8FAFC`. Zero elevation, zero shadow.
- **Level 1 (Card & Module Layer):** Surface `#FFFFFF`, enclosed by a crisp `1px solid #E2E8F0` border. Shadow is an imperceptible, diffuse contact shade: `0px 1px 3px 0px rgba(11, 25, 44, 0.04), 0px 1px 2px -1px rgba(11, 25, 44, 0.03)`.
- **Level 2 (Active & Hover Cards, Popovers):** Surface `#FFFFFF`, `1px solid #CBD5E1`. Shadow: `0px 4px 6px -1px rgba(11, 25, 44, 0.06), 0px 2px 4px -2px rgba(11, 25, 44, 0.04)`. Card translates -1px vertically on hover to signal affordance.
- **Level 3 (Modals, Study Focus Trays, Drawers):** Surface `#FFFFFF`, `1px solid #E2E8F0`. Shadow: `0px 20px 25px -5px rgba(11, 25, 44, 0.08), 0px 8px 10px -6px rgba(11, 25, 44, 0.04)`. Modals pair with a 40% opacity backdrop blur over `#0B192C` (`rgba(11, 25, 44, 0.40)` with `backdrop-filter: blur(4px)`).

## Shapes

The geometric framework balances human approachability with structural composure.

- **Primary Containers & Panels (`rounded-2xl` / 1.5rem / 24px):** Applied to major surface wrappers, hero diagnostic cards, syllabus track boards, and modal overlays.
- **Standard Cards & Interactive Groupings (`rounded-xl` / 1rem / 16px):** Applied to individual module items, task lists, analytical dashboards, and study cards.
- **Controls, Buttons & Input Fields (`rounded-md` / 0.5rem / 8px):** Provides crisp precision for functional targets, preventing input forms from feeling excessively child-like or casual.
- **Indicators, Chips & Badges (`rounded-full` / 9999px):** Applied to category tags, mastery status pills, and progress track pills to ensure immediate differentiation from actionable rectangular cards.

## Components

### Buttons
- **Primary:** Background `#0B192C`, text `#FFFFFF`, radius 8px, padding `10px 20px`. Hover: `#1E2E42`. Active: `#0F172A`. Focus-visible: 2px outline in `#0D9488` with 2px offset.
- **Accent (Teal Action):** Background `#0D9488`, text `#FFFFFF`, radius 8px. Hover: `#14B8A6`. Focus: 2px ring `#0D9488`.
- **Secondary / Outline:** Background `#FFFFFF`, text `#0B192C`, 1px border `#E2E8F0`, radius 8px. Hover: `#F8FAFC` background with `#CBD5E1` border.
- **Ghost:** Background transparent, text `#64748B`, radius 8px. Hover: `#F1F5F9`, text `#0B192C`.

### Cards
- **Standard Academic Card:** White background, 1px border `#E2E8F0`, border-radius 16px (`rounded-xl`), inner padding `space-lg` (24px). Hover state transitions border to `#CBD5E1` and elevates to Level 2.
- **Diagnostic Alert Card:** White background, left border 4px solid in semantic color (`#EF4444` for gaps, `#F59E0B` for misconceptions, `#10B981` for completed modules), remaining edges 1px border `#E2E8F0`.

### Chips & Badges
- **Discipline Tag (Indigo):** Background `rgba(79, 70, 229, 0.08)`, text `#4F46E5`, 1px border `rgba(79, 70, 229, 0.20)`, radius 9999px, padding `4px 10px`, font `label-sm`.
- **Mastery Confirmed (Emerald):** Background `rgba(16, 185, 129, 0.10)`, text `#065F46`, radius 9999px, padding `4px 10px`, font `label-sm`.
- **Misconception Warning (Amber):** Background `rgba(245, 158, 11, 0.10)`, text `#92400E`, radius 9999px, padding `4px 10px`, font `label-sm`.
- **Concept Gap (Rose):** Background `rgba(239, 68, 68, 0.10)`, text `#991B1B`, radius 9999px, padding `4px 10px`, font `label-sm`.

### Form Controls & Inputs
- **Text Inputs & Selects:** Height 44px, background `#FFFFFF`, border 1px solid `#CBD5E1`, radius 8px, font `body-md` (`#0B192C`). Placeholder text in `#94A3B8`. Hover: `#94A3B8` border. Focus: `#0D9488` border with 3px shadow ring `rgba(13, 148, 136, 0.15)`.
- **Checkboxes & Radios:** 18px × 18px, border 1.5px solid `#94A3B8`, radius 4px (checkbox) or circular (radio). Checked state: `#0D9488` fill with clean white SVG checkmark.

### Domain-Specific Components
- **Progress Trackers:** Full-width 6px height track in `#E2E8F0` with smooth border-radius 9999px. Progress bar uses `#0D9488` (linear learning) or `#10B981` (syllabus mastery) with transition duration `300ms ease-out`.
- **Diagnostic Knowledge Nodes:** Tree or list view with dot indicators (`8px × 8px` rounded-full) denoting prerequisites, pending synthesis tasks, and evaluated proficiencies.
- **Citation & Source Block:** Left-bordered 2px solid `#4F46E5`, background `#F8FAFC`, radius `0 8px 8px 0`, padding `12px 16px`, typography `body-sm` with text color `#334155`.